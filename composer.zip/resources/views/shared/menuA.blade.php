<li class="nav-item dropdown {{ $homeActivo }}">
    <a href="#" class="nav-link text-primary dropdown-toggle" data-toggle="dropdown">Servicios</a>
    <div class="dropdown-menu">
        <a href="{{ route( 'suma', '#queofrecemos-head-section')}}" class="dropdown-item">Qué ofrecemos</a>
        <!-- <a href="{{ url('/xxx') }}" class="dropdown-item">Qué ofrecemos</a> -->
        <a href="{{ route( 'suma', '#financiera-head-section')}}" class="dropdown-item">Área Financiera</a>
        <a href="{{ route( 'suma', '#contable-head-section')}}" class="dropdown-item">Área Contable</a>
        <a href="{{ route( 'suma', '#fiscal-head-section')}}" class="dropdown-item">Área Fiscal</a>
        <a href="{{ route( 'suma', '#mercantil-head-section')}} " class=" dropdown-item ">Área Mercantil</a>
        <a href="{{ route( 'suma', '#administracion-head-section') }} " class="dropdown-item ">Administración</a>
        <a href="#consultoria-head-section " class="dropdown-item ">Consultoría - RRHH</a>
    </div>
</li>
