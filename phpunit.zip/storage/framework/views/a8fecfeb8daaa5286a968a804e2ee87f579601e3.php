<nav class="navbar navbar-expand-md navbar-light bg-light fixed-top" id="main-nav">
    <div class="container">
        <a class="navbar-brand " href=<?php echo e(route( 'welcome')); ?>>
            <img src="<?php echo e(asset('img/logosuma.jpg')); ?>" height="30" class="d-inline-block" id="sumaLogo" alt="Suma Apoyo Empresarial">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse"
            aria-expanded="false" aria-label="Toggle Navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown <?php echo e($homeActivo); ?>">
                    <a href="#" class="nav-link text-primary dropdown-toggle" data-toggle="dropdown"> Suma</a>
                    <div class="dropdown-menu">
                        <a href="<?php echo e(route( 'suma')); ?>" class="dropdown-item">Inicio</a>
                        <a href="<?php echo e(route( 'suma', '#queofrecemos-head-section')); ?>" class="dropdown-item">Qué ofrecemos</a>
                        <a href="<?php echo e(route( 'suma', '#financiera-head-section')); ?>" class="dropdown-item">Área Financiera</a>
                        <a href="<?php echo e(route( 'suma', '#contable-head-section')); ?>" class="dropdown-item">Área Contable</a>
                        <a href="<?php echo e(route( 'suma', '#fiscal-head-section')); ?>" class="dropdown-item">Área Fiscal</a>
                        <a href="<?php echo e(route( 'suma', '#mercantil-head-section')); ?> " class=" dropdown-item ">Área Mercantil</a>
                        <a href="<?php echo e(route( 'suma', '#administracion-head-section')); ?> " class="dropdown-item ">Administración</a>
                        <a href="#consultoria-head-section " class="dropdown-item ">Consultoría - RRHH</a>
                    </div>
                </li>
                <li class="nav-item <?php echo e($equipoActivo); ?> ">
                    <a href=<?php echo e(route( 'equipo')); ?> class="nav-link text-primary ">Equipo</a>
                </li>
                <li class="nav-item <?php echo e($clientesActivo); ?> ">
                    <a href=<?php echo e(route( 'clientes')); ?> class="nav-link text-primary ">Clientes</a>
                </li>
                <li class="nav-item <?php echo e($contactoActivo); ?> ">
                    <a href=<?php echo e(route( 'contacto')); ?> class="nav-link text-primary ">Contacto</a>
                </li>
                <li class="nav-item ">
                    <a href="#definir " class="nav-link text-primary ">English</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
