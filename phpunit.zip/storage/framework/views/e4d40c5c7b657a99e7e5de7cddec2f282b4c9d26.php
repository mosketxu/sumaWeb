<ul class="nav nav-pills nav-fill sticky-bottom">
    <li class="nav-item"> <a href="<?php echo e(route( 'suma', '#financiera-head-section')); ?>">Área Financiera</a></li>
    <li class="nav-item"> <a href="<?php echo e(route( 'suma', '#contable-head-section')); ?>">Área Contable</a></li>
    <li class="nav-item"> <a href="<?php echo e(route( 'suma', '#fiscal-head-section')); ?>">Área Fiscal</a></li>
    <li class="nav-item"> <a href="<?php echo e(route( 'suma', '#mercantil-head-section')); ?> ">Área Mercantil</a></li>
    <li class="nav-item"> <a href="<?php echo e(route( 'suma', '#administracion-head-section')); ?> ">Administración</a></li>
    <li class="nav-item"> <a href="#consultoria-head-section ">Consultoría - RRHH</a></li>
</ul>
