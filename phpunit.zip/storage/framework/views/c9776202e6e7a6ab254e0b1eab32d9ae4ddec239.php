<li class="nav-item <?php echo e($homeActivo); ?>">
    <a href=<?php echo e(route( 'suma')); ?> class="nav-link text-primary ">Servicios</a>
</li>
